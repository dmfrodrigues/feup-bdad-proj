.mode columns
.headers on
PRAGMA foreign_keys=ON;

DROP TRIGGER bill_price_insert;

DROP TRIGGER bill_price_update;

DROP TRIGGER bill_price_delete;
