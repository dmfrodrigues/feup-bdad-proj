.mode columns
.headers on
PRAGMA foreign_keys=ON;

DROP TRIGGER delivery_stamp_insert;

DROP TRIGGER delivery_stamp_update;
