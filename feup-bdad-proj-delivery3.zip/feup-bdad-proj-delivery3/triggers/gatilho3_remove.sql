.mode columns
.headers on
PRAGMA foreign_keys=ON;

DROP TRIGGER postman_role_insert;

DROP TRIGGER manager_role_insert;

DROP TRIGGER shopkeeper_role_insert;
